export interface AuthResponse {
  token: string;
  role: string;
  email: string;
  userId: number;
}